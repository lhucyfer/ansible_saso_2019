<?php

       phpinfo();

?>